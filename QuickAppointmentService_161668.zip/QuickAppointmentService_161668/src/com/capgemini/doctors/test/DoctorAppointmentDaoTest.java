package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;

public class DoctorAppointmentDaoTest extends DoctorAppointmentDao {

	DoctorAppointment c=new DoctorAppointment();
	DoctorAppointmentDao a= new DoctorAppointmentDao();
	@Test
	public void testAddDoctorAppointmentDetails() {
			assertNotNull(a.addDoctorAppointmentDetails(c));
		}
	
	@Test
    public void  testDisplayPatient(){
		int b=1234;
    	assertNotNull(c);
    }
	
	@Test
	public void testGetAppointmentDetails(){
		int b=1234;
		assertNotNull(a);
	}
}
