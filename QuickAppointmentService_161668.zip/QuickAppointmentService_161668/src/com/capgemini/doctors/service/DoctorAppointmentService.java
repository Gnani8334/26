package com.capgemini.doctors.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	DoctorAppointmentDao dao=new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		// TODO Auto-generated method stub
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		// TODO Auto-generated method stub
		return dao.getAppointmentDetails(appointmentId);
	}

	@Override
	public DoctorAppointment displayPatient(int appointmentId) {
		// TODO Auto-generated method stub
		return dao.displayPatient(appointmentId);
	}

	public boolean validateAppointmentId(int id) {
		// TODO Auto-generated method stub
		return dao.validateAppointmentId(id);
	}
	
	public  String toTitleCase(String givenString) {
	    String[] arr = givenString.split(" ");
	    StringBuffer sb = new StringBuffer();

	    for (int i = 0; i < arr.length; i++) {
	        sb.append(Character.toUpperCase(arr[i].charAt(0)))
	            .append(arr[i].substring(1)).append(" ");
	    }          
	    return sb.toString().trim();
	}  
	public boolean validatePatientName(String patientName){
    	boolean flag=false;
    	Pattern firstName=Pattern.compile("^[A-Za-z]{1,}\\s?[A-Za-z]{0,}$");
    	Matcher mtch = firstName.matcher(patientName);
		if(patientName.length()>=2&&mtch.matches()){
			flag=true;
		}
    return flag;
    }

	public boolean validatePhoneNumber(String mobileNo) {
		// TODO Auto-generated method stub
		Pattern mobileNo1=Pattern.compile("^[7-9][0-9]{9}"); 
		Matcher mobileMatch=mobileNo1.matcher(mobileNo);
		return mobileMatch.matches();
	}

	public boolean validateEmailAddress(String email) {
        Pattern p = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
        Matcher m = p.matcher(email);
        return m.matches();
 }

	public boolean validateAge(int age) {
		// TODO Auto-generated method stub
		if(age>0&&age<100){
			return true;
		}
		return false;
	}

	public int validateGender(String gender) {
		// TODO Auto-generated method stub
		if(gender.equals("M")||(gender.equals("MALE"))){
			return 1;
		}else if(gender.matches("F")||gender.matches("FEMALE")){
			return 2;
		}
		return 0;
	}

	public boolean validateProblemName(String choice1,DoctorAppointment bean) {
		// TODO Auto-generated method stub
		if(choice1.equals("Heart")){
		    bean.setProblemName("Heart");
		    bean.setDoctorName("Dr. Brijesh Kumar");
		    bean.setAppointmentStatus("APPROVED");
		    return true;
	    }
	    else if(choice1.equals("Gynecology")){
		    bean.setProblemName("Gynecology");
		    bean.setDoctorName("Dr. Sharda Singh");
		    bean.setAppointmentStatus("APPROVED");
		    return true;
	    }
	    else if(choice1.equals("Diabetes")){
		    bean.setProblemName("Diabetes");
		    bean.setDoctorName("Dr. Heena Khan");
		    bean.setAppointmentStatus("APPROVED");
		    return true;
	    }
	    else if(choice1.equals("ENT")){
		    bean.setProblemName("ENT");
		    bean.setDoctorName("Dr. Paras mal");
		    bean.setAppointmentStatus("APPROVED");
		    return true;
	    }
	    else if(choice1.equals("Bone")){
		    bean.setProblemName("Bone");
		    bean.setDoctorName("Dr. Renuka Kher");
		    bean.setAppointmentStatus("APPROVED");
		    return true;
	    }
	    else if(choice1.equals("Dermatology")){
		    bean.setProblemName("Dermatology");
		    bean.setDoctorName("Dr. Kanika Kapoor");
		    bean.setAppointmentStatus("APPROVED");
		    return true;
	    }
	    else{
	    	bean.setProblemName(choice1);
	    	bean.setDoctorName("Null");
	    	bean.setAppointmentStatus("DISAPPROVED");
	    }
		return false;
	}

}
