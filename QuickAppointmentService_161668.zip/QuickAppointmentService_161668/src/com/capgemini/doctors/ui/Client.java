package com.capgemini.doctors.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.PatientNotFound;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoctorAppointmentService service=new DoctorAppointmentService();
		while (true) {
			System.out.println("WELCOME TO QUICK DOCTOR APPOINTMENT SERVICE");
			System.out.println("ENTER 1 To Book Doctor Appointment");
			System.out.println("ENTER 2 To View Doctor Appointment");
			System.out.println("ENTER 3 To Exit");

			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				DoctorAppointment bean=new DoctorAppointment();
				boolean valid=false;
				do {
			       
					BufferedReader pname= new BufferedReader(new InputStreamReader(System.in));
					String n;
						try {
							System.out.println("Enter Name of the patient:");
							n=pname.readLine();
							String s=service.toTitleCase(n);
							bean.setPatientName(s);
							valid=service.validatePatientName(s);
							if(valid){
								break;
							}else{
								System.err.println("Please enter valid name. Name should contain atleast 2 letters");
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
				} while (!valid);
				boolean valid1=false;
				do{
					System.out.println("Enter Phone Number:");
					String phoneNo=sc.next();
					valid1=service.validatePhoneNumber(phoneNo);
					if(valid1){
						bean.setPhoneNumber(phoneNo);
						break;
					}
				else{
					System.err.println("Please enter valid mobile number. It should be 10digits");
				    }
				}while(!valid1);
				boolean valid2=false;
				do{
					System.out.println("Enter Email:");
					String email = sc.next();
				    valid2=service.validateEmailAddress(email);
				    if(valid2){
				        bean.setEmail(email);
				    }
			    else{
					System.err.println("Please enter valid email address");
				}
				}while(!valid2);
				boolean valid3=false;
				do{
					System.out.println("Enter Age:");
					int age = sc.nextInt();
				    valid3=service.validateAge(age);
				    if(valid3){
				    	bean.setAge(age);
					    break;
				}else{
					System.err.println("Please enter valid age. Age is a number between 0 and 100");
				}
				}while(!valid3);
				int valid4=0;
				do{
					System.out.println("Enter Gender:");
					String gender = sc.next();
				    valid4=service.validateGender(gender.toUpperCase());
				    if(valid4==1||valid4==2){
				    	bean.setGender(gender);
					    break;
				}else{
					System.err.println("Please enter valid gender. Please Type  M for Male or F for Female");
				}
				}while(valid4==0);
				boolean valid5=false;
				do{
					System.out.println("Enter Problem Name From Below Given List:");
				    System.out.println("ENTER Heart");
				    System.out.println("ENTER Gynecology");
				    System.out.println("ENTER Diabetes");
				    System.out.println("ENTER ENT");
				    System.out.println("ENTER Bone");
				    System.out.println("ENTER Dermatology");
				    String problemName=sc.next();
				    bean.setProblemName(problemName);
				    valid5=service.validateProblemName(problemName,bean);
				    if(valid5){
					    break;
				    }
				    else{
				    	System.out.println("Please enter valid Problem Name");
				    }
				}while(!valid5);
					int isAdded = service.addDoctorAppointmentDetails(bean);
					if (isAdded==1) {
						System.out.println("Your Doctor Appointment has been successfully registered, your appointment ID is:<"+bean.getAppointmentId()+">");
						//System.out.println(bean);
					} else {
						try {
							throw new PatientNotFound("Appointment Not Registered");
						} catch (PatientNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
		       break;
			case 2:
				System.out.println("Enter Appointment ID To view Doctor Appointment Status");
				int id = sc.nextInt();
				boolean valid6 = service.validateAppointmentId(id);
				if (valid6) {
					DoctorAppointment c = service.displayPatient(id);
					if (c.getAppointmentId()==id) {
						service.getDoctorAppointmentDetails(id);
					} else {
						try {
							throw new PatientNotFound("Please enter valid Appointment Id");
						} catch (PatientNotFound e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}
				}
				break;
				
			case 3:
				System.out.println("********************************************");
				System.out.println("--------------------------------------------");
				System.out.println("Thank You for using Our Quick Doctor Appointment Service");
				System.out.println("--------------------------------------------");
				System.out.println("********************************************");
                sc.close();
				System.exit(0);
				break;

			default:
				System.out.println("Please Enter Valid Input Option");
				break;
			}
		}

	}

}
