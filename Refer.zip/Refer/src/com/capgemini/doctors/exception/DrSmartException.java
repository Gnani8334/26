package com.capgemini.doctors.exception;

public class DrSmartException extends Exception {
String msg;
public DrSmartException(String msg){
	this.msg=msg;
}

public String getMessage(){
	return msg;
}
}
