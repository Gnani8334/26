package com.capgemini.flats.ui;

import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.OwnerException;
import com.cg.frss.service.FlatRegistrationServiceImpl;

public class Client {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		FlatRegistrationDTO flat=new FlatRegistrationDTO();
		/*FlatRegistrationDAOImpl dao=new FlatRegistrationDAOImpl();*/
		FlatRegistrationServiceImpl service=new FlatRegistrationServiceImpl();
		
		while(true){
			   System.out.println("\n_________ Menu______________\n");
			   System.out.println("1.Register a Flat\n2 Display details");
			   System.out.println("3.Exit\n");
			   
			     System.out.println("please Enter your Choice:");
			     int choice=sc.nextInt();
			     boolean flag=false;
			   switch (choice) {
			case 1:
			do{
				System.out.print("Existing Owner IDS Are:-[1,2,3,4,5,6,7,8,9,10] \n");
				System.out.print("Please Enter your Owner id from above List:");
			    int ownerId=	sc.nextInt();
			    if(service.validateOwnerId(ownerId)){
			    
			    	System.out.println(ownerId);
			    	flat.setOwnerId(ownerId);
			    	flag=true;
			    }else{
			    	 System.err.println("owner does not exists");
			    	 flag=false;
			    	 
			    }
			}while(flag==false);
			    
				do{
				 System.out.print("Select the Flat Type(1-1BHK,2-2BHK):");
				 String flatType=sc.next();
				 if(service.validateFlatType(flatType)){
			     System.out.println(flatType);
				 flat.setFlatType(flatType);
				 flag=true;
				 }else{
					  System.err.println("please enter the valid Flat Type from  above list");
					  flag=false;
				 }
				  
				}while(flag==false);
			
				 System.out.print("Enter the Flat area in sq.ft:");
					int flatArea=sc.nextInt();
				
					 System.out.println(flatArea);
					 flat.setFlatArea(flatArea);
					 int rentAmount=0;
			do{
				System.out.print("Enter desired rent amount Rs:");
			    rentAmount= sc.nextInt();
				if(service.validateRentAmount(rentAmount)){
				System.out.println(rentAmount);
				flat.setRentAmount(rentAmount);
				flag=true;
				}else{
					 System.err.println("please enter valid Amount ");
					 flag=false;
				}
			}while(flag==false);
			
			do{
			  System.out.print("Enter the  desired deposit Amount Rs:");
			  double depositAmount=	 sc.nextDouble();
			  if(service.validateDepositAmount(depositAmount,rentAmount)){
			  System.out.println(depositAmount);
			  flat.setDepositAmount(depositAmount);
			  flag=true;
			  }else{
				   System.err.println("please enter amount greater than the rent Amount");
				   flag=false;
			  }
			}while(flag==false)	;
			
				 int registrationId=(int) (Math.random()*9000)+1000;
				 System.out.println("Flat Successfully registered.RegistrationId<"+registrationId+">");
				 
				 if(service.registerFlat(flat)!=null){
				 flat.setRegistrationId(registrationId);
				 System.out.println(flat);
				 
				 }
				 else{
					 try {
						throw new OwnerException();
					} catch (OwnerException e) {
						// TODO Auto-generated catch block
						System.out.println("ownerId does Not exists"+e.getMessage());
					}
				 }
				 break;
				 
			case 2:
				
				System.err.println("enter yor Reg Id");
				registrationId =sc.nextInt();
				System.out.println(service.getFlatDetails(registrationId));
				break;
			case 3:
				System.out.println(" Thank you for registering ");
				System.exit(0);
				  break;
			default:
				System.out.println("please enter  the valid choice :");
				
				break;
			}
		}
		
	}

}
