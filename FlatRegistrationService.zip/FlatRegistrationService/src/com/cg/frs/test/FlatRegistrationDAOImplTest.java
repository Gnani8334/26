package com.cg.frs.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class FlatRegistrationDAOImplTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
