/**
 * 
 */
/**
 * @author asus
 *
 */
package com.cg.frs.dto;