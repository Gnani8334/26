package com.cg.frs.dto;

public class FlatRegistrationDTO {

	private int OwnerId;
	private String flatType;
	private  int flatArea;
	private double rentAmount;
	private double depositAmount;
	private  int registrationId;
	public FlatRegistrationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlatRegistrationDTO(int ownerId, String flatType, int flatArea, double rentAmount, double depositAmount,
			int registrationId) {
		super();
		OwnerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
		this.registrationId = registrationId;
	}
	public int getOwnerId() {
		return OwnerId;
	}
	public void setOwnerId(int ownerId) {
		OwnerId = ownerId;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public int getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	public double getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO [OwnerId=" + OwnerId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depositAmount=" + depositAmount + ", registrationId="
				+ registrationId + "]";
	}

}
