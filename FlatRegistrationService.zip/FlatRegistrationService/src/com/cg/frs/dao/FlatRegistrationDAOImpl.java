package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.frs.dto.FlatRegistrationDTO;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {
     Map<Integer,FlatRegistrationDTO> flatMap=new HashMap<Integer,FlatRegistrationDTO>();
	//ArrayList<FlatRegistrationDTO> list=new ArrayList<FlatRegistrationDTO>();

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		
		int key=flat.getRegistrationId();
		flatMap.put(key, flat);
				System.out.println("details are stored");
		return flat;
		
		//list.add(flat);
		//System.out.println("Record added successfully");
		
		//return flat;
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		return null;
		
		
		/*ArrayList<Integer> ownerId=new ArrayList<Integer>();
	
		for (FlatRegistrationDTO obj : list) {
			ownerId.add(obj.getOwnerId());
			
		}
		// TODO Auto-generated method stub
		return ownerId;*/
	}
   public FlatRegistrationDTO getFlatDetails(int registrationId){
	   FlatRegistrationDTO c=null;
	   for (FlatRegistrationDTO flatRegistrationDTO : flatMap.values()) {
		   if(flatRegistrationDTO.getRegistrationId()==registrationId){
			    c=flatRegistrationDTO;
		   }
		
	}
	return c;
	   
	   
	   
   }
}
