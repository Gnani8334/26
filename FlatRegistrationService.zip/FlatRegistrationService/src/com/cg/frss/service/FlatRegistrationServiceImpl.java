package com.cg.frss.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatRegistrationDTO;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	FlatRegistrationDAOImpl dao=new FlatRegistrationDAOImpl();

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		// TODO Auto-generated method stub
		return dao.registerFlat(flat);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		// TODO Auto-generated method stub
		return dao.getAllOwnerIds();
	}

	public boolean validateOwnerId(int ownerId) {
		if(ownerId>10){
	   return false;
		}
		return true;
	}

	public boolean validateFlatType(String flatType) {
		if(flatType.equals("1")||flatType.equals("2")){
			return true; 
		}
		return false;
	}

	public boolean validateRentAmount(int rentAmount) {
		if(rentAmount<=6999){
		return false;
		}
		return true;
	}

	public boolean validateDepositAmount(double depositAmount, int rentAmount) {
	if(depositAmount>rentAmount){
		return true;
	}
		return false;
	}

	@Override
	public FlatRegistrationDTO getFlatDetails(int registrationId) {
		// TODO Auto-generated method stub
		return dao.getFlatDetails(registrationId);
	}

}
